package com.onlineshopping.flipkart.entity;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "orders_10709374")
public class Orders {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int orderID;

    @ManyToOne
    private Customers customer;

    @ManyToOne
    private Shippers shipper;

    private Date date;

    public Orders() {
    }

    public Orders(int orderID, Date date) {
        this.orderID = orderID;
        this.date = date;
    }

    public Shippers getShipper() {
        return shipper;
    }

    public void setShipper(Shippers shipper) {
        this.shipper = shipper;
    }

    public Customers getCustomer() {
        return customer;
    }

    public void setCustomer(Customers customer) {
        this.customer = customer;
    }

    public int getOrderID() {
        return orderID;
    }

    public void setOrderID(int orderID) {
        this.orderID = orderID;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}

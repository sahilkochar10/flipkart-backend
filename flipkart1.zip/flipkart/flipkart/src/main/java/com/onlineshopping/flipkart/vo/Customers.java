//package com.onlineshopping.flipkart.vo;
//
//import lombok.Getter;
//
//        import javax.validation.constraints.Digits;
//        import javax.validation.constraints.NotBlank;
//        import javax.validation.constraints.NotEmpty;
//
//@Getter
//public class Customers {
//    int customerID;
//    @Digits(integer = 6, fraction = 0)
//    int postalCode;
//    @NotEmpty
//    String customerName;
//    @NotEmpty
//    String address;
//    @NotEmpty
//    String city;
//    @NotEmpty
//    String country;
//}
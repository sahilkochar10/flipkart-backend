package com.onlineshopping.flipkart.service;

import com.onlineshopping.flipkart.entity.Customers;
import com.onlineshopping.flipkart.exceptions.CustomerAlreadyExistsException;
import com.onlineshopping.flipkart.exceptions.CustomerNotFoundException;
import org.springframework.http.ResponseEntity;
import com.onlineshopping.flipkart.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerService {

    @Autowired
    CustomerRepository customerRepository;

    public ResponseEntity<List<Customers>> getCustomers() {
        return new ResponseEntity<>(customerRepository.findAll(), HttpStatus.OK);
    }

    public void saveCustomer(List<Customers> customers) throws CustomerAlreadyExistsException {
        for (Customers customer : customers) {
            if (customerRepository.findById(customer.getCustomerID()).isPresent()) {
                throw new CustomerAlreadyExistsException(customer.getCustomerID());
            }
            customerRepository.save(customer);
        }
    }

    public void updateCustomer(List<Customers> customers) throws CustomerNotFoundException {
        for (Customers customer : customers) {
            if (customerRepository.findById(customer.getCustomerID()).isEmpty()) {
                throw new CustomerNotFoundException(customer.getCustomerID());
            }
            customerRepository.save(customer);
        }
    }
}
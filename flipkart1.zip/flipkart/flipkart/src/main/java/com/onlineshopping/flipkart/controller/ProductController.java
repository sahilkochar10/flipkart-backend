package com.onlineshopping.flipkart.controller;

import com.onlineshopping.flipkart.service.ProductService;
import com.onlineshopping.flipkart.entity.Products;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ProductController {

    @Autowired
    ProductService productService;

    @GetMapping("/api/v1/products")
    ResponseEntity<List<Products>> getProduct(){
        return productService.getProducts();
    }

    @GetMapping("/api/v1/products/{pid}")
    ResponseEntity<Products> getProductByid(@PathVariable Integer pid) {
        return productService.getProductByid(pid);
    }

    @PostMapping("/api/v1/products")
    ResponseEntity<String> addProducts(@RequestBody List<Products> products){
        productService.addProducts(products);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PutMapping("/api/v1/products")
    ResponseEntity<String> editProducts(@RequestBody List<Products> products){
        productService.updateProducts(products);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}


package com.onlineshopping.flipkart.service;

import com.onlineshopping.flipkart.repository.ProductRepository;
import com.onlineshopping.flipkart.entity.Products;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {
    @Autowired
    ProductRepository productRepository;

    public ResponseEntity<List<Products>> getProducts(){
        return  new ResponseEntity<>(productRepository.findAll(), HttpStatus.OK);
    }

    public void addProducts(List<Products> product){
        for(Products p:product) {
            productRepository.save(p);
        }
    }

    public ResponseEntity<Products> getProductByid(Integer pid){
        return new ResponseEntity<>(productRepository.findById(pid).get(), HttpStatus.OK);
    }

    public void updateProducts(List<Products> products){
        for(Products p:products){
            productRepository.save((p));
        }
    }
}

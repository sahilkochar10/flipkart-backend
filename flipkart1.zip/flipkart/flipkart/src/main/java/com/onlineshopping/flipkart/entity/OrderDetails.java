package com.onlineshopping.flipkart.entity;


import javax.persistence.*;

@Entity
@Table(name = "OrderDetails_10709374")
public class OrderDetails{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int orderDetailId;

    private int orderID,productID;

    @ManyToOne
    @JoinColumn(name = "orderID", insertable = false, updatable = false)
    private Orders order;

    @ManyToOne
    @JoinColumn(name = "productID", insertable = false, updatable = false)
    private Products product;

    int quantity;

    public OrderDetails() {
    }

    public OrderDetails(int orderDetailId, int quantity) {
        this.orderDetailId = orderDetailId;
        this.quantity = quantity;
    }

    public int getOrderDetailId() {
        return orderDetailId;
    }

    public void setOrderDetailId(int orderDetailId) {
        this.orderDetailId = orderDetailId;
    }

    public Orders getOrder() {
        return order;
    }

    public void setOrder(Orders order) {
        this.order = order;
    }

    public Products getProduct() {
        return product;
    }

    public void setProduct(Products product) {
        this.product = product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getOrderID() {
        return orderID;
    }

    public void setOrderID(int orderID) {
        this.orderID = orderID;
    }

    public int getProductID() {
        return productID;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }
}
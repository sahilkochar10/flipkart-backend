//package com.onlineshopping.flipkart.service;
//
//import com.onlineshopping.flipkart.entity.OrderDetails;
//import com.onlineshopping.flipkart.entity.Products;
//
//public class OrderDetailsService {
//    public static OrderDetails convertToOrderDetail(com.onlineshopping.flipkart.vo.OrderDetail orderDetailsVo) {
//        OrderDetails orderDetail = new OrderDetails();
//        Products product = new Products();
//        product.setProductID(orderDetailsVo.getProductID());
//        orderDetail.setProduct(product);
//        orderDetail.setQuantity(orderDetailsVo.getQuantity());
//        return orderDetail;
//    }
//}

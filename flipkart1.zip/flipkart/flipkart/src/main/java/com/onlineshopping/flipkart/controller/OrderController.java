package com.onlineshopping.flipkart.controller;



        import com.onlineshopping.flipkart.entity.Orders;
        import com.onlineshopping.flipkart.service.OrderService;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.http.HttpStatus;
        import org.springframework.http.ResponseEntity;
        import org.springframework.stereotype.Controller;
        import org.springframework.web.bind.annotation.GetMapping;
        import org.springframework.web.bind.annotation.PostMapping;
        import org.springframework.web.bind.annotation.RequestBody;

        import java.util.List;

@Controller
public class OrderController {
    @Autowired
    OrderService orderService;

    @GetMapping("/api/v1/order")
    ResponseEntity<List<Orders>> getOrders() {
        return orderService.getOrders();
    }

    @PostMapping("/api/v1/order")
    ResponseEntity<String> saveOrders(@RequestBody List<Orders> orders) {
        orderService.saveOrders(orders);
        return new ResponseEntity<>(HttpStatus.OK);
    }

}